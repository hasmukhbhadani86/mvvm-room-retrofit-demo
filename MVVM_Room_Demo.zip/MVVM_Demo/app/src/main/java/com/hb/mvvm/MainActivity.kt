package com.hb.mvvm

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.RecyclerView
import com.hb.mvvm.adapter.HeroesAdapter
import com.hb.mvvm.model.HeroResponse
import com.hb.mvvm.viewmodel.HeroesViewModel
import java.util.*

/** Reference link
 * MVVM : https://github.com/Amit00a/MVVMNews
 * ROOM : https://github.com/smartherd/ArchitectureComponentsRoom
 */
class MainActivity : AppCompatActivity()
{
    private var recyclerView: RecyclerView? = null
    private var adapter: HeroesAdapter? = null
    private var heroList = ArrayList<HeroResponse>()

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupRecyclerView()

        //Set View model observe to set data into the recycler view
        val model = ViewModelProviders.of(this).get(HeroesViewModel::class.java)
        model.getHeroesList()?.observe(this, HeroListObserver())
    }

    @SuppressLint("WrongConstant")
    private fun setupRecyclerView()
    {
        if (adapter == null)
        {
            recyclerView = findViewById(R.id.rvData)

            adapter = HeroesAdapter(this@MainActivity, heroList)
            recyclerView!!.adapter = adapter
            recyclerView!!.itemAnimator = DefaultItemAnimator()
            recyclerView!!.isNestedScrollingEnabled = true
        }
        else
        {
            adapter!!.notifyDataSetChanged()
        }
    }

    inner class HeroListObserver : Observer<List<HeroResponse>>
    {
        override fun onChanged(t: List<HeroResponse>?) {
            heroList.addAll(t!!)
            adapter!!.notifyDataSetChanged()
        }

    }
}
