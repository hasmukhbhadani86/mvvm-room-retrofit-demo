package com.hb.mvvm.webservice

import com.hb.mvvm.model.HeroResponse
import retrofit2.Call
import retrofit2.http.GET

interface HeroApi {

    @get:GET("marvel")
    val heroes: Call<List<HeroResponse>>
}