package com.hb.mvvm.webservice

object AppConstants {
    var BASE_URL = "https://simplifiedcoding.net/demos/"
}
