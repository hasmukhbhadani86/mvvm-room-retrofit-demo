package com.hb.mvvm.repository

import android.annotation.SuppressLint
import android.os.AsyncTask
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.hb.mvvm.HeroApplication
import com.hb.mvvm.model.HeroResponse
import com.hb.mvvm.utils.NetworkUtils
import com.hb.mvvm.webservice.HeroApi
import com.hb.mvvm.webservice.RetrofitService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HeroRepository {

    private val TAG = this.javaClass.simpleName
    private var heroList: MutableLiveData<List<HeroResponse>>? = null
    private val heroApi: HeroApi

    init
    {
        heroList = MutableLiveData()
        heroApi = RetrofitService.createService(HeroApi::class.java)
    }

    companion object
    {
        private var heroRepository: HeroRepository? = null

        fun instance(): HeroRepository
        {
            if (heroRepository == null) {
                heroRepository = HeroRepository()
            }
            return heroRepository!!
        }
    }

    fun getHeroes():LiveData<List<HeroResponse>>?
    {
            if(NetworkUtils.isOnline(HeroApplication.getAppContext()!!))
            {
                HeroApplication.dbInstance!!.heroDao().deleteAllRecords()
                Log.e(TAG,"===> Delete Records")
                callServiceToGetData()
            }
            else
            {
                if(HeroApplication.dbInstance!!.heroDao().getCount()>0)
                {
                    Log.e(TAG,"===> Get data from Db")
                    heroList!!.value = HeroApplication.dbInstance!!.heroDao().allHeros
                }
                else
                {
                    Toast.makeText(HeroApplication.getAppContext()!!,"Internet connection lost", Toast.LENGTH_LONG).show()
                }
            }

        return heroList
    }

    private fun callServiceToGetData()
    {
        heroApi.heroes.enqueue(object : Callback<List<HeroResponse>>
        {
            override fun onResponse(call: Call<List<HeroResponse>>, response: Response<List<HeroResponse>>) {

                //finally we are setting the list to our MutableLiveData
                //                heroList.setValue(response.body());

                InsertAsyncTask(response.body()!!).execute()


            }

            override fun onFailure(call: Call<List<HeroResponse>>, t: Throwable) {

            }
        })
    }


   @SuppressLint("StaticFieldLeak")
   inner class InsertAsyncTask(var list: List<HeroResponse>) : AsyncTask<Void, Void, Void>()
    {
        override fun doInBackground(vararg params: Void?): Void? {
            Log.e(TAG,"===> Insert data to Db")
            HeroApplication.dbInstance!!.heroDao().insertAllHeros(list)

            return null
        }

        @SuppressLint("WrongThread")
        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)

            heroList!!.value = HeroApplication.dbInstance!!.heroDao().allHeros
        }
    }
}