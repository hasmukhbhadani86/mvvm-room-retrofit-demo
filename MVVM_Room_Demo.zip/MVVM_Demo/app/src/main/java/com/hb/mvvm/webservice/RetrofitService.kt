package com.hb.mvvm.webservice

import com.hb.mvvm.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class RetrofitService {

    companion object {

        private val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(AppConstants.BASE_URL)
            .client(getOkHttpClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()


        private fun getOkHttpClient(): OkHttpClient
        {
            val interceptor = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

            val okHttpBuilder = OkHttpClient.Builder()
            if (BuildConfig.DEBUG)
            {
                okHttpBuilder.addInterceptor(interceptor)
            }
            okHttpBuilder.readTimeout(100, TimeUnit.SECONDS)
                .connectTimeout(100, TimeUnit.SECONDS)
                .addInterceptor(interceptor)

            return okHttpBuilder.build()
        }


        fun <S> createService(serviceClass: Class<S>): S {
            return retrofit.create(serviceClass)
        }

        //In case only one Api class in the application
        fun getClient(): HeroApi {
            return createService(HeroApi::class.java)
        }
    }
}
