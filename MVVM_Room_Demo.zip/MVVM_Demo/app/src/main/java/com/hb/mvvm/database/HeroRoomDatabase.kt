package com.hb.mvvm.database

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.hb.mvvm.model.HeroResponse

@Database(entities = [HeroResponse::class], version = 1)
abstract class HeroRoomDatabase : RoomDatabase() {

    @WorkerThread
    abstract fun heroDao(): HeroDao

    companion object {
        @Volatile
        private var noteRoomInstance: HeroRoomDatabase? = null

        fun getDatabase(context: Context): HeroRoomDatabase? {
            if (noteRoomInstance == null) {
                synchronized(HeroRoomDatabase::class.java) {
                    if (noteRoomInstance == null) {
                        noteRoomInstance = Room.databaseBuilder(
                            context.applicationContext,HeroRoomDatabase::class.java, "hero_database")
                            .allowMainThreadQueries()
                            .build()
                    }
                }
            }
            return noteRoomInstance
        }
    }
}
