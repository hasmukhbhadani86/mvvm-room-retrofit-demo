package com.hb.mvvm

import android.app.Application
import com.hb.mvvm.database.HeroRoomDatabase

class HeroApplication : Application() {
    init {
        appContext = this
    }

    companion object {
        private var appContext: HeroApplication? = null
        private var heroRoomDatabase: HeroRoomDatabase? = null

        fun getAppContext() : HeroApplication?
        {
            if (appContext == null) {
                synchronized(HeroApplication::class.java) {
                    appContext = HeroApplication()
                }
            }
            return appContext
        }

        val dbInstance: HeroRoomDatabase?
            get() {
                if (heroRoomDatabase == null) {
                    heroRoomDatabase = HeroRoomDatabase.getDatabase(this.getAppContext()!!)
                }
                return heroRoomDatabase
            }
    }

}
