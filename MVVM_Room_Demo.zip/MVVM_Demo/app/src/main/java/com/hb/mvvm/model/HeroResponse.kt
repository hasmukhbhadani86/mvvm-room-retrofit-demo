package com.hb.mvvm.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "heros")
class HeroResponse(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val name: String,
    val realname: String,
    val team: String,
    val firstappearance: String,
    val createdby: String,
    val publisher: String,
    val imageurl: String,
    val bio: String
)