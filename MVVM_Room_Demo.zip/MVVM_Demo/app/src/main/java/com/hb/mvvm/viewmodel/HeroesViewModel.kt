package com.hb.mvvm.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.hb.mvvm.model.HeroResponse
import com.hb.mvvm.repository.HeroRepository

class HeroesViewModel : ViewModel() {

    private var heroRepository: HeroRepository? = null

    init {
        if (heroRepository == null) {
            heroRepository = HeroRepository.instance()
        }
    }

    fun getHeroesList(): LiveData<List<HeroResponse>>?
    {
        return heroRepository!!.getHeroes()
    }

}