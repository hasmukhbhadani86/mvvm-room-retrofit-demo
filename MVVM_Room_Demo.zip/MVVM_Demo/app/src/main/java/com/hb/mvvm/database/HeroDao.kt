package com.hb.mvvm.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.hb.mvvm.model.HeroResponse

@Dao
interface HeroDao {

    @get:Query("SELECT * FROM heros")
    val allHeros: List<HeroResponse>

    @Query("SELECT COUNT(*) FROM heros")
    fun getCount(): Int

    @Insert
    fun insertAllHeros(note: List<HeroResponse>)

    @Query("DELETE FROM heros")
    fun deleteAllRecords()

    @Query("SELECT * FROM heros WHERE name=:name")
    fun getHeros(name: String): LiveData<HeroResponse>

    @Update
    fun update(note: HeroResponse)

    @Delete
    fun delete(note: HeroResponse): Int
}
